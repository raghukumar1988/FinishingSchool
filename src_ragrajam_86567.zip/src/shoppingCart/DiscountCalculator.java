package shoppingCart;

public class DiscountCalculator {

	public static void main(String[] args) {
		String productType = "veggies";
		double finalBillPrice = 0;
		if (!productType.equals("grocery"))
			finalBillPrice = calculateDiscount(new User("affiliate", 3, 990));
		// finalPrice = calculateDiscount(new User("employee", 1, 850));
		finalBillPrice = finalBillPrice - ((finalBillPrice / 100) * 5);  //Applying $5 discount For every $100 on the bill
		System.out.println("Final price after Dicsount--> " + finalBillPrice);

	}

	private static double calculateDiscount(User user) {
		double billedAmount = user.getBilledAmount();

		if (null != user && user.getUserType().equals("employee")) {
			billedAmount = billedAmount - (billedAmount * 0.3);//30% discount for employee
		}
		if (null != user && user.getUserType().equals("affiliate")) {
			billedAmount = billedAmount - (billedAmount * 0.1);//10% discount for affiliate
		} else if (user.yearsInRelation > 2) {
			billedAmount = billedAmount - (billedAmount * 0.05); // 5% discount for customer for over 2 years,
		}

		return billedAmount;

	}

}
