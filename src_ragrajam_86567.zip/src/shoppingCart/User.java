package shoppingCart;

public class User {
	String userType;
	double yearsInRelation;
	double billedAmount;

	public User(String empType, double years, double amt) {
		this.userType = empType;
		this.yearsInRelation = years;
		this.billedAmount = amt;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public double getYearsInRelation() {
		return yearsInRelation;
	}

	public void setYearsInRelation(double yearsInRelation) {
		this.yearsInRelation = yearsInRelation;
	}

	public double getBilledAmount() {
		return billedAmount;
	}

	public void setBilledAmount(double billedAmount) {
		this.billedAmount = billedAmount;
	}



}
