package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorExample {

	public static void main(String[] args) {
		List<Employee> emp = new ArrayList<>();
		emp.add(new Employee(12, "Raghu", "Pumar", 12000));
		emp.add(new Employee(17, "Maju", "Kumar", 18000));
		emp.add(new Employee(9, "Bavi", "Sumar", 9000));
		emp.add(new Employee(57, "Aakesh", "Bumar", 89564));
		emp.add(new Employee(57, "Gakesh", "Aumar", 56000));
		emp.add(new Employee(45, "Vignesh", "Lumar", 85023));
		emp.add(new Employee(35, "Saravana", "Gumar", 44856));
		System.out.println("###############Actual Order################");
		printValues(emp);
		System.out.println("###############Sort By Id################");
		sortbyId(emp);
		System.out.println("###############Sort By First Name################");
		sortbyFirstName(emp);
		System.out.println("###############Sort By Salary################");
		sortbySalary(emp);

	}

	private static void sortbySalary(List<Employee> emp) {
		Collections.sort(emp, new SalaryComparator());
		for (Employee em : emp) {
			System.out.println(em);
		}

	}

	private static void sortbyFirstName(List<Employee> emp) {
		Comparator<Employee> fnameComp = new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getFirstName().compareTo(o2.getFirstName());
			}
		};
		Collections.sort(emp, fnameComp);

		for (Employee em : emp) {
			System.out.println(em);
		}

	}

	private static void sortbyId(List<Employee> emp) {
		Collections.sort(emp, new IdComparator());
		for (Employee em : emp) {
			System.out.println(em);
		}
	}

	private static void printValues(List<Employee> emp) {
		for (Employee em : emp) {
			System.out.println(em);
		}
	}

}
