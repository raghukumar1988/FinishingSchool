package org.cap.service;

import java.util.List;

import org.cap.model.Product;

public interface IProductDbService {
	public List<Product> getAllProducts();

	public Product findProduct(Integer productId);

	public List<Product> deleteProduct(Integer productId);

	public List<Product> addProduct(Product product);
	public List<Product> findByquantity(int quantity);
	public List<Product> findByquantityAndPrice(int quantity,double price);
	public List<Product> findByproductNameContaining(String productName);
}
