package org.cap.service;

import java.util.List;

import org.cap.dao.IProductDbDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productDbService")
public class ProductDbServiceImpl implements IProductDbService{
	
	@Autowired
	private IProductDbDao productDbDao;

	@Override
	public List<Product> getAllProducts() {
		
		return productDbDao.findAll();
	}

	@Override
	public Product findProduct(Integer productId) {
		
		return productDbDao.getOne(productId);
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		productDbDao.deleteById(productId);
		return productDbDao.findAll();
	}

	//insert and update
	@Override
	public List<Product> addProduct(Product product) {
		productDbDao.save(product);
		return productDbDao.findAll();
	}

	@Override
	public List<Product> findByquantity(int quantity) {
		
		return productDbDao.findByquantity(quantity);
	}

	@Override
	public List<Product> findByquantityAndPrice(int quantity, double price) {
		// TODO Auto-generated method stub
		return productDbDao.findByquantityAndPrice(quantity, price);
	}

	@Override
	public List<Product> findByproductNameContaining(String productName) {
		// TODO Auto-generated method stub
		return productDbDao.findByproductNameContaining(productName);
	}

}
