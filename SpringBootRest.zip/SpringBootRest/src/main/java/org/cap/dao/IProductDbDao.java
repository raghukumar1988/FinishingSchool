package org.cap.dao;

import java.util.List;

import org.cap.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("productDbDao")
@Transactional
public interface IProductDbDao extends JpaRepository<Product, Integer>{

	public List<Product> findByquantity(int quantity);
	public List<Product> findByquantityAndPrice(int quantity,double price);
	public List<Product> findByproductNameContaining(String productName);
}
