package org.cap.boot;

import org.cap.config.JavaConfiguration;
import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class TestClass {

	public static void main(String[] args) {
	
		AbstractApplicationContext context=
				new AnnotationConfigApplicationContext(JavaConfiguration.class);
		
		Employee employee=context.getBean(Employee.class);
		//Address address=context.getBean(Address.class);
		System.out.println(employee);
		//System.out.println(address);
	}

}
