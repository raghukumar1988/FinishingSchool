package org.cap.model;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int employeeId;
	private String empName;
	private double salary;
	
	@Autowired
	private Address address;
	
	public Employee() {
		
	}
	
	public Employee(int employeeId, String empName, double salary) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.salary = salary;
	}
	
	
	
	public Employee(int employeeId, String empName, double salary, Address address) {
		super();
		System.out.println("Calling Employee Constructor..........");
		this.employeeId = employeeId;
		this.empName = empName;
		this.salary = salary;
		this.address = address;
	}
	
	public void init_Method() {
		System.out.println("Bean Initialized.....");
	}

	
	public void destroy_Method() {
		System.out.println("Bean Destroyed.....");
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		System.out.println("Calling Address Setter Method.......");
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", empName=" + empName + ", salary=" + salary + ", address="
				+ address + "]";
	}

	
	

}
