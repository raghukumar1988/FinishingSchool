package org.cap.config;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({MyClass.class})
public class JavaConfiguration {

	@Bean
	public Employee getEmployee() {
		Employee employee=new Employee();
		employee.setEmployeeId(123);
		employee.setEmpName("Tom");
		employee.setSalary(45000);
		return employee;
	}
	
	@Bean("address")
	public Address getAddress() {
		Address address=new Address();
		address.setStreetName("West Car st");
		address.setCity("Chennai");
		return address;
	}
	
	@Bean("address1")
	public Address getAddress1() {
		Address address=new Address();
		address.setStreetName("North Avvenue");
		address.setCity("Pune");
		return address;
	}
	
	
}
