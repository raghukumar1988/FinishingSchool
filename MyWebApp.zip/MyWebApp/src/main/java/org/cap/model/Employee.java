package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	@Id
	private int employeeId;
	private String empName;
	private double salary;
	
	@ManyToOne
	@JoinColumn(name="company_fk")
	private Company company;
	
	@ManyToMany
	@JoinTable(name="emps_projects" ,
			joinColumns= {@JoinColumn(name="employees") },
			inverseJoinColumns= {@JoinColumn(name="projects")})
	private List<Project> projects=new ArrayList<>();
	
	/*@OneToOne
	private Address address;
*/
	public Employee() {
		
	}
	
	
	
	public Employee(int employeeId, String empName) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
	}



	public Employee(int employeeId, String empName, double salary) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.salary = salary;
		
	}

	
	
	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	/*public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}*/

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", empName=" + empName + ", salary=" + salary +
				 "]";
	}
	
	
	

}
