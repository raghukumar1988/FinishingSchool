package org.cap.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {

	@Id
	@GeneratedValue
	private int addressId;
	private String address;
	
	@OneToOne
	@JoinColumn(name="emp_fk")
	private Employee employee;
	
	public Address() {
		
	}
	

	public Address(String address) {
		super();
		this.address = address;
	}


	public Address(int addressId, String address, Employee employee) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.employee = employee;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address=" + address + ", employee=" + employee + "]";
	}
	
	
	
}
