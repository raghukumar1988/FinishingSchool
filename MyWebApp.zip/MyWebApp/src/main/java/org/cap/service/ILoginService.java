package org.cap.service;

import org.cap.model.Employee;

public interface ILoginService {
	
	public boolean isValidLogin(Employee employee);

}
