package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.Employee;

public class LoginServiceImpl implements ILoginService{
	
	private ILoginDao loginDao=new LoginDaoImpl();

	@Override
	public boolean isValidLogin(Employee employee) {
		
		/*if(employee.getEmployeeId() ==123 && 
				employee.getEmpName().equals("tom123"))
			return true;*/
		return loginDao.isValidLogin(employee);
	}

}
