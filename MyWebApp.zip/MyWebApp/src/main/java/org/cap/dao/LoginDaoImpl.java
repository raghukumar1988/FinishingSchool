package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Employee;

public class LoginDaoImpl implements ILoginDao{
	
	public EntityManager getEntityManager() {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		return emf.createEntityManager();
	}
	

	@Override
	public boolean isValidLogin(Employee employee) {
		EntityManager entityManager=getEntityManager();
		EntityTransaction transaction=
				entityManager.getTransaction();
		transaction.begin();
			String sql="from Employee e where e.employeeId="+employee.getEmployeeId()
				+  " and e.empName='"+employee.getEmpName() +"'";
			List<Employee> employees=entityManager.createQuery(sql).getResultList();
		transaction.commit();
		
			if(employees.size()>0)
				return true;
		
		
		return false;
	}

}
