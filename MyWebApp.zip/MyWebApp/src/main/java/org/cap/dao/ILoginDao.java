package org.cap.dao;

import org.cap.model.Employee;

public interface ILoginDao {
	public boolean isValidLogin(Employee employee);
}
