package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.Employee;

import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;


@WebServlet("/ValidateLogin")
public class ValidateLogin extends HttpServlet {
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		
		Employee loginPojo=new Employee(Integer.parseInt(userName),
				userPwd);
		
		ILoginService loginService=new LoginServiceImpl();
		if(loginService.isValidLogin(loginPojo)) {
			response.sendRedirect("mainPage.html");
			/*request.getRequestDispatcher("mainPage.html")
				.forward(request, response);*/
		}else {
			response.sendRedirect("index.html");
		}
		
	}

}
