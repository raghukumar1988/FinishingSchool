package org.cap.boot;

import java.util.List;

import org.cap.model.Address;
import org.cap.model.CollectionDemo;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {

		AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("collection.xml");
		
		CollectionDemo demo=(CollectionDemo)context.getBean("collect");
		
		List<String> names=demo.getNames();
		List<Address> addresses=demo.getAddresses();
		System.out.println(names);
		
		System.out.println(addresses);
		context.close();
		
	}

}
