package org.cap.util;

public enum UserType {
	EMPLOYEE, AFFILIATE
}
