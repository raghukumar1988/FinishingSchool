package org.cap.util;

public enum ItemType {
	GROCERY, COSTMETICS, CLOTHS

}
