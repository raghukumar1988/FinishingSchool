package org.cap.pojo;

import org.cap.util.ItemType;

public class Item {
	
	private int itemId;
	private String itemName;
	private double price;
	private ItemType itemType;
	private int quantity;
	
	public Item() {
		
	}
	
	
	public Item(int itemId, String itemName, double price, ItemType itemType, int quantity) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.itemType = itemType;
		this.quantity = quantity;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public ItemType getItemType() {
		return itemType;
	}
	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + ", itemType=" + itemType
				+ ", quantity=" + quantity + "]";
	}
	
	

}
