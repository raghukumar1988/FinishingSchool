package org.cap.service;

import java.util.Date;

import org.cap.pojo.Item;
import org.cap.pojo.User;
import org.cap.util.ItemType;
import org.cap.util.UserType;

public class StoreServiceImpl implements IStoreService{

	public double calculateNetPayableAmount(User user) {
		
		//Amount Calculation
		double netPriceGrocery=0.0;
		double netprice=0.0;
		for(Item item:user.getItems()) {
			if(item.getItemType()==ItemType.GROCERY) {
				netPriceGrocery+=item.getPrice()*item.getQuantity();
			}else {
				netprice+=item.getPrice()*item.getQuantity();
			}
		}
		
		//apply discount
		double discount=calculateDiscount(user);
		netprice-=(netprice*discount);
		
		double finalAmount=netprice+netPriceGrocery;
		
		//For every $100 on the bill, there would be a $ 5 discount
		if(finalAmount>=100)
			finalAmount-=(int)(finalAmount/100)*5;
		
		return finalAmount;
	}

	public double calculateDiscount(User user) {
		
		double discount=0.0;
		if(user.getUserType()==UserType.EMPLOYEE)
		{
			discount=0.30;
		}else if(user.getUserType() == UserType.AFFILIATE) {
			discount=0.10;
		}else {
			int year=user.getRegistrationDate().getYear() -
					 new Date().getYear();
			if(year>=2)
				discount=0.05;
		}
		
		return discount;
	}

}
