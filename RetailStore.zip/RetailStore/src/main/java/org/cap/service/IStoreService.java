package org.cap.service;

import org.cap.pojo.User;

public interface IStoreService {

	public double calculateDiscount(User user);
	public double calculateNetPayableAmount(User user);
}
