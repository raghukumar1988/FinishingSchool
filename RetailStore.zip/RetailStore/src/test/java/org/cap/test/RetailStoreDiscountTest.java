package org.cap.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.cap.pojo.Item;
import org.cap.pojo.User;
import org.cap.service.IStoreService;
import org.cap.service.StoreServiceImpl;
import org.cap.util.ItemType;
import org.cap.util.UserType;
import org.junit.Before;
import org.junit.Test;

public class RetailStoreDiscountTest {

	private IStoreService iStoreService;
	private User user;
	private List<Item> items=new ArrayList<Item>();
	
	@Before
	public void init() {
		iStoreService=new StoreServiceImpl();
		 user=new User(1001, "Tom", "Jerry", new Date(1999, 2, 12), UserType.EMPLOYEE);
		 Item item=new Item(1, "aaa", 10, ItemType.GROCERY, 20);
		 Item item1=new Item(2, "bbb",5 , ItemType.CLOTHS, 200);
		 Item item2=new Item(3, "ccc", 2, ItemType.COSTMETICS, 100);
		 
		 items.add(item);
		 items.add(item1);
		 items.add(item2);
		 user.setItems(items);
		 
	}
	
	@Test
	public void testCalculateDiscountForEmployee() {
		double discount=iStoreService.calculateDiscount(user);
		
		assertEquals(0.30, discount,0.0);
	}
	
	
	@Test
	public void testNetPayableAmountForEmployee() {
		double amount=iStoreService.calculateNetPayableAmount(user);
		assertEquals(990, amount,0.0);
	}
	
}
