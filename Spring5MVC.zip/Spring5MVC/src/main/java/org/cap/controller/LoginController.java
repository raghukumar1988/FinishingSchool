package org.cap.controller;

import org.cap.model.LoginPojo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	
	@RequestMapping("/")
	public ModelAndView getIndexPage() {
		return new ModelAndView("index","login",new LoginPojo());
	}
	
	@RequestMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@ModelAttribute("login")LoginPojo loginPojo) {
		if(loginPojo.getUserName().equals("tom") && 
				loginPojo.getUserPwd().equals("tom123")) {
			map.addAttribute("userName", loginPojo.getUserName());
			return "success";
		}
		
		return "redirect:/";
	}
	
	/*@RequestMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("usePwd")String usePwd) {
		
		
		
		if(userName.equals("tom") && 
				usePwd.equals("tom123")) {
			map.addAttribute("userName", userName);
			return "success";
		}
		
		return "redirect:/";
	}*/
	
}
