package org.cap.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Address address=new Address("South Car Street");
		Employee employee=new Employee(1001, "Tom Jack", 23000);
		address.setEmployee(employee);
		
		Address address1=new Address("North Car Street");
		Employee employee1=new Employee(1002, "Annie Paul", 34000);
		address1.setEmployee(employee1);
		
		Address address2=new Address("West Car Street");
		Employee employee2=new Employee(1003, "Tim Tom", 12000);
		address2.setEmployee(employee2);
		
		
		Company tcs=new Company(1, "TATA Consultancy Services");
		Company capg=new Company(2, "Capgemini Consultancy Services");
		
		employee.setCompany(tcs);
		employee1.setCompany(capg);
		employee2.setCompany(capg);
		
		
		Project project=new Project(1, "Citi Bank");
		Project project1=new Project(2, "CNA Banking");
		Project project2=new Project(3, "TU Banking");
		
		employee.getProjects().add(project);
		employee.getProjects().add(project2);
		employee1.getProjects().add(project1);
		employee2.getProjects().add(project2);
		employee2.getProjects().add(project1);
		
		entityManager.persist(employee);
		entityManager.persist(address);
		entityManager.persist(employee1);
		entityManager.persist(address1);
		entityManager.persist(employee2);
		entityManager.persist(address2);
		entityManager.persist(tcs);
		entityManager.persist(capg);
		
		entityManager.persist(project);
		entityManager.persist(project1);
		entityManager.persist(project2);
		
		
		
		transaction.commit();
		
		entityManager.close();
	}

}
