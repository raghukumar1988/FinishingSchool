package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

import com.cap.model.Product;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao{
	
	private static AtomicInteger productId=new AtomicInteger(1001);
	private static List<Product> products=getDummyDB();
	
	public static List<Product> getDummyDB(){
		List< Product> products=new ArrayList<>();
		products.add(new Product(productId.getAndIncrement(), "Samsung Mobile", 3, 45000, new Date(2020-1900, 2, 23, 1, 1)));
		products.add(new Product(productId.getAndIncrement(), "Sony Mobile",34, 12434, new Date(2023-1900, 3, 23, 1, 1)));
		products.add(new Product(productId.getAndIncrement(), "Iphone", 12, 67000, new Date(2025-1900, 11, 23, 1, 1)));
		products.add(new Product(productId.getAndIncrement(), "Honor", 8, 23000, new Date(2030-1900, 10, 23, 1, 1)));
		products.add(new Product(productId.getAndIncrement(), "Lenova Mobile", 44, 12000, new Date(2019-1900, 2, 23, 1, 1)));
		
		
		return products;
	}

	@Override
	public List<Product> getAllProducts() {
		
		return products;
	}

	@Override
	public Product findProduct(Integer productId) {
		for(Product product:products) {
			if(product.getProductId()==productId)
				return product;
		}
		return null;
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		boolean flag=false;
		Iterator<Product> iterator= products.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				iterator.remove();
			}
		}
		if(flag)
			return products;
		else
			return null;
	
	}

	@Override
	public List<Product> addProduct(Product product) {
		products.add(product);
		return products;
	}
}
