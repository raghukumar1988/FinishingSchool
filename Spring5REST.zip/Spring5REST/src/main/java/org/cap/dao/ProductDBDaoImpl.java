package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cap.model.Product;

@Repository("productDBDao")
@Transactional
public class ProductDBDaoImpl implements IProductDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Product> getAllProducts() {
		String sql="from Product";
		List<Product> products= entityManager.createQuery(sql).getResultList();
		
		return products;
	}

	@Override
	public Product findProduct(Integer productId) {
		
		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		Product product=findProduct(productId);
		if(product!=null) {
			entityManager.remove(product);
			return getAllProducts();
		}
		return null;
	}

	@Override
	public List<Product> addProduct(Product product) {
		entityManager.persist(product);
		return getAllProducts();
	}

}
