package org.cap.service;

import java.util.List;

import org.cap.dao.IProductDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.model.Product;

@Service("productDbService")
public class ProductDbServiceImpl implements IProductService{
	@Autowired
	private IProductDao productDBDao;
	
	@Override
	public List<Product> getAllProducts() {
		
		return productDBDao.getAllProducts();
	}

	@Override
	public Product findProduct(Integer productId) {
		return productDBDao.findProduct(productId);
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		
		return productDBDao.deleteProduct(productId);
	}

	@Override
	public List<Product> addProduct(Product product) {
		
		return productDBDao.addProduct(product);
	}

}
